<?php
$_['text_title'] = 'Maksāt ar Visa / MasterСard';
$_['decta_order_status_failed'] = 'ERROR: Платёж получен, но верификация не удалась';
$_['decta_order_status_success'] = 'Заказ оплачен';
$_['decta_order_status_pending'] = 'Ожидается платёж';
$_['decta_order_status_invoice_sent_text'] = 'Счёт запрошен на e-mail';