<?php
$_['text_title'] = 'Оплата Visa / MasterСard';
$_['payment_decta_order_status_failed'] = 'ERROR: Платёж получен, но верификация не удалась';
$_['payment_decta_order_status_success'] = 'Заказ оплачен';
$_['payment_decta_order_status_pending'] = 'Ожидается платёж';
$_['payment_decta_order_status_invoice_sent_text'] = 'Счёт запрошен на e-mail';
?>
