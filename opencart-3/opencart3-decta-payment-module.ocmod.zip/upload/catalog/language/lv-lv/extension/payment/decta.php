<?php
$_['text_title'] = 'Maksājiet ar Visa / MasterCard';
$_['payment_decta_order_status_failed'] = 'KĻŪDA: maksājums tika saņemts, taču pasūtījuma pārbaude neizdevās';
$_['payment_decta_order_status_success'] = 'Maksājums veiksmīgs';
$_['payment_decta_order_status_pending'] = 'Gaida samaksu';
$_['payment_decta_order_status_invoice_sent_text'] = 'Pieprasīts rēķins uz e-pastu';
$_['payment_decta_invoice_for_payment'] = 'Maksājuma rēķins #';
?>
