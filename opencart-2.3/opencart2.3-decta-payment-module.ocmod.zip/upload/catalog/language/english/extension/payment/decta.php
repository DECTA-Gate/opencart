<?php
$_['text_title'] = 'Pay with Visa / MasterCard';
$_['decta_order_status_failed'] = 'ERROR: Payment received, but order verification failed';
$_['decta_order_status_success'] = 'Payment successful';
$_['decta_order_status_pending'] = 'Awaiting payment';
$_['decta_order_status_invoice_sent_text'] = 'Requested invoice to email';