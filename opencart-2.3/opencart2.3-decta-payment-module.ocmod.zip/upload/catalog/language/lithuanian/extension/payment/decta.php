<?php
// Text
$_['text_title'] = 'Visa / MasterCard';
$_['text_paid_status'] = 'Paid';
?>