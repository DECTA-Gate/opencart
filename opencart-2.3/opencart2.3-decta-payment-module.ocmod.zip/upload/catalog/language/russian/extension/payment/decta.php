<?php
$_['text_title'] = 'Оплата Visa / MasterСard';
$_['decta_order_status_failed'] = 'ОШИБКА: платеж был получен, однако проверка заказа не прошла';
$_['decta_order_status_success'] = 'Заказ оплачен';
$_['decta_order_status_pending'] = 'Ожидается платёж';
$_['decta_order_status_invoice_sent_text'] = 'Счёт запрошен на e-mail';
$_['payment_decta_invoice_for_payment'] = 'Счет на оплату #';