<?php
$_['text_title'] = 'Maksāt ar Visa / MasterCard';
$_['decta_order_status_failed'] = 'ERROR: Maksājums saņemts, bet verifikācija neizdevās';
$_['decta_order_status_success'] = 'Maksājums veiksmīgs';
$_['decta_order_status_pending'] = 'Gaida maksājumu';
$_['decta_order_status_invoice_sent_text'] = 'Rēķins pieprasīts uz e-pastu';