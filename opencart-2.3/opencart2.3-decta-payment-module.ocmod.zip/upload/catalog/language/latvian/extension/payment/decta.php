<?php
$_['text_title'] = 'Maksāt ar Visa / MasterCard';
$_['decta_order_status_failed'] = 'KĻŪDA: maksājums tika saņemts, taču pasūtījuma pārbaude neizdevās';
$_['decta_order_status_success'] = 'Maksājums veiksmīgs';
$_['decta_order_status_pending'] = 'Gaida samaksu';
$_['decta_order_status_invoice_sent_text'] = 'Pieprasīts rēķins uz e-pastu';
$_['payment_decta_invoice_for_payment'] = 'Maksājuma rēķins #';